---
title: 
layout: notes
course: College Prep Math
---

- Solve equations in one variable algebraically.
- Solve a rational equation.
- Find a linear equation.
- Given the equations of two lines, determine whether their graphs are parallel or perpendicular.
- Write the equation of a line parallel or perpendicular to a given line.

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
