---
title: 
layout: notes
course: College Prep Math
---

- Set up a linear equation to solve a real-world application.
- Use a formula to solve a real-world application.

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
