---
title: 
layout: notes
course: College Prep Math
---

- Add and subtract complex numbers.
- Multiply and divide complex numbers.
- Simplify powers of $i$

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
