---
title: 
layout: notes
course: College Prep Math
---

- Solve quadratic equations by factoring.
- Solve quadratic equations by the square root property.
- Solve quadratic equations by completing the square.
- Solve quadratic equations by using the quadratic formula.

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
