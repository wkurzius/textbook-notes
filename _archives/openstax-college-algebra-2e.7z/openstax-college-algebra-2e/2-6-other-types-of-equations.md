---
title: 
layout: notes
course: College Prep Math
---

- Solve equations involving rational exponents.
- Solve equations using factoring.
- Solve radical equations.
- Solve absolute value equations.
- Solve other types of equations.

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
