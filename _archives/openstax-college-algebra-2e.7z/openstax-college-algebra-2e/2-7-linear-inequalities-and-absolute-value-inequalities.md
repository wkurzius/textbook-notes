---
title: 
layout: notes
course: College Prep Math
---

- Use interval notation
- Use properties of inequalities.
- Solve inequalities in one variable algebraically.
- Solve absolute value inequalities.

## Assignment

- 
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
