---
title: 
layout: notes
course: College Prep Math
---

{: .lesson-dates}
Lesson date: .

- objectives

## Assignment

- assignment
- *Recommended*: all **vocabulary** and concept blocks copied into notes

---
